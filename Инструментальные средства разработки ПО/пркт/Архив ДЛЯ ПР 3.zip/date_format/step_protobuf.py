import profile_pb2
from helpers import protobuf_profile
p=protobuf_profile(); b=p.SerializeToString()
print('=== Protobuf ===\nHEX:',b.hex(),'\nРазмер:',len(b),'байт')
p2=profile_pb2.Profile(); p2.ParseFromString(b)
assert p2.name==p.name
print('Десериализация успешна:',p2.name)
