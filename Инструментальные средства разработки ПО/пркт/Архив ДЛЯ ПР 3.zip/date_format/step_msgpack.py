import msgpack
from data import PROFILE
b=msgpack.packb(PROFILE,use_bin_type=True)
print('=== MessagePack ===\nHEX:',b.hex(),'\nРазмер:',len(b),'байт')
assert msgpack.unpackb(b,raw=False)==PROFILE
print('Десериализация успешна:',PROFILE['name'])
