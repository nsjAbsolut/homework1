import yaml
from data import PROFILE
s=yaml.dump(PROFILE,allow_unicode=True,sort_keys=False,default_flow_style=False)
print('=== YAML ===\n'+s+'\nРазмер:',len(s.encode()),'байт')
assert yaml.safe_load(s)==PROFILE
print('Десериализация успешна:',PROFILE['name'])
