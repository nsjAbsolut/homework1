import cbor2
from data import PROFILE
b=cbor2.dumps(PROFILE)
print('=== CBOR ===\nHEX:',b.hex(),'\nРазмер:',len(b),'байт')
assert cbor2.loads(b)==PROFILE
print('Десериализация успешна:',PROFILE['name'])
