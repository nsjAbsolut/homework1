PROFILE = {"id": 42, "name": "Анна Смирнова", "age": 22, "is_student": True, "courses": ["Математика", "Физика", "Информатика"], "address": {"city": "Москва", "zip": "101000"}}
