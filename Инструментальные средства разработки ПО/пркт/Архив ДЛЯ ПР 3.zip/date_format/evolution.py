import profile_pb2
from pathlib import Path
p=profile_pb2.Profile()
p.ParseFromString(Path('received/message_protobuf.pb').read_bytes())
print('Имя:',p.name)
print('Email (новое поле):',repr(p.email))
assert p.email==''
