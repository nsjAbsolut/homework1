import socket,os,json,msgpack,cbor2,profile_pb2
HOST,PORT='127.0.0.1',9999
EXT={'json':'json','msgpack':'msgpack','cbor':'cbor','protobuf':'pb'}
def receive_exact(conn,n):
 data=b''
 while len(data)<n:
  chunk=conn.recv(n-len(data))
  if not chunk: raise ConnectionError('Соединение закрыто')
  data+=chunk
 return data
def handle(data,fmt):
 if fmt=='json': return json.loads(data.decode())
 if fmt=='msgpack': return msgpack.unpackb(data,raw=False)
 if fmt=='cbor': return cbor2.loads(data)
 p=profile_pb2.Profile(); p.ParseFromString(data)
 return {'id':p.id,'name':p.name,'courses':list(p.courses)}
def main():
 with socket.socket() as server:
  server.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
  server.bind((HOST,PORT)); server.listen(1)
  print(f'Сервер слушает {HOST}:{PORT}...',flush=True)
  conn,addr=server.accept()
  with conn:
   fmt={b'J':'json',b'M':'msgpack',b'C':'cbor',b'P':'protobuf'}[receive_exact(conn,1)]
   size=int.from_bytes(receive_exact(conn,4),'big')
   payload=receive_exact(conn,size)
   print(f'=== Получено {len(payload)} байт, формат: {fmt} ===')
   print('HEX:',payload.hex())
   try: print('TEXT:',payload.decode('utf-8'))
   except UnicodeDecodeError: print('TEXT: <не текст, бинарные данные>')
   print('DATA:',handle(payload,fmt))
   os.makedirs('received',exist_ok=True)
   path=f'received/message_{fmt}.{EXT[fmt]}'
   with open(path,'wb') as f:f.write(payload)
   print('[СОХРАНЕНО]',path)
if __name__=='__main__': main()
