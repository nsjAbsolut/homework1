import xml.etree.ElementTree as ET
from helpers import dict_to_xml
from data import PROFILE
s=ET.tostring(dict_to_xml('profile',PROFILE),encoding='unicode')
print('=== XML ===\n'+s+'\nРазмер:',len(s.encode()),'байт')
assert ET.fromstring(s).find('name').text==PROFILE['name']
print('Имя пользователя:',PROFILE['name'])
