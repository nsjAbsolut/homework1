# Minimal RFC 8949 CBOR subset for this assignment (dict/list/str/int/bool).
def _head(major,n):
 return bytes([(major<<5)|n]) if n<24 else bytes([(major<<5)|24,n]) if n<256 else bytes([(major<<5)|25])+n.to_bytes(2,'big') if n<65536 else bytes([(major<<5)|26])+n.to_bytes(4,'big')
def dumps(obj):
 if obj is True:return b'\xf5'
 if obj is False:return b'\xf4'
 if isinstance(obj,int):return _head(0,obj) if obj>=0 else _head(1,-1-obj)
 if isinstance(obj,str):
  b=obj.encode();return _head(3,len(b))+b
 if isinstance(obj,list):return _head(4,len(obj))+b''.join(map(dumps,obj))
 if isinstance(obj,dict):return _head(5,len(obj))+b''.join(dumps(k)+dumps(v) for k,v in obj.items())
 raise TypeError(type(obj))
def loads(data):
 def read(i):
  b=data[i];i+=1;major=b>>5;n=b&31
  if major==7 and n in (20,21):return n==21,i
  if n==24:n=data[i];i+=1
  elif n==25:n=int.from_bytes(data[i:i+2],'big');i+=2
  elif n==26:n=int.from_bytes(data[i:i+4],'big');i+=4
  if major==0:return n,i
  if major==1:return -1-n,i
  if major==3:return data[i:i+n].decode(),i+n
  if major==4:
   arr=[]
   for _ in range(n):v,i=read(i);arr.append(v)
   return arr,i
  if major==5:
   d={}
   for _ in range(n):k,i=read(i);v,i=read(i);d[k]=v
   return d,i
  raise ValueError('Unsupported CBOR type')
 obj,end=read(0)
 if end!=len(data):raise ValueError('Trailing bytes')
 return obj
