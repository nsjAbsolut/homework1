from data import PROFILE
import profile_pb2
import xml.etree.ElementTree as ET

def protobuf_profile():
 p=profile_pb2.Profile()
 p.id=PROFILE['id']; p.name=PROFILE['name']; p.age=PROFILE['age']; p.is_student=PROFILE['is_student']
 p.courses.extend(PROFILE['courses']); p.address.city=PROFILE['address']['city']; p.address.zip=PROFILE['address']['zip']
 return p

def dict_to_xml(tag,d):
 elem=ET.Element(tag)
 for k,v in d.items():
  if isinstance(v,dict): elem.append(dict_to_xml(k,v))
  elif isinstance(v,list):
   le=ET.SubElement(elem,k)
   for item in v: ET.SubElement(le,'item').text=str(item)
  else: ET.SubElement(elem,k).text=str(v)
 return elem
