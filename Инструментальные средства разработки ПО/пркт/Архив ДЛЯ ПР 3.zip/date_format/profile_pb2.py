# Generated-equivalent protobuf descriptors; works without protoc.
from google.protobuf import descriptor_pb2, descriptor_pool, message_factory
fd = descriptor_pb2.FileDescriptorProto()
fd.name = 'profile.proto'
fd.syntax = 'proto3'
a = fd.message_type.add(); a.name = 'Address'
for number,name in [(1,'city'),(2,'zip')]:
 f=a.field.add(); f.name=name; f.number=number; f.label=1; f.type=9
m=fd.message_type.add(); m.name='Profile'
for number,name,typ in [(1,'id',5),(2,'name',9),(3,'age',5),(4,'is_student',8),(5,'courses',9),(6,'address',11),(7,'email',9)]:
 f=m.field.add(); f.name=name; f.number=number; f.type=typ; f.label=3 if name=='courses' else 1
 if name=='address': f.type_name='.Address'
pool=descriptor_pool.DescriptorPool(); pool.Add(fd)
Address=message_factory.GetMessageClass(pool.FindMessageTypeByName('Address'))
Profile=message_factory.GetMessageClass(pool.FindMessageTypeByName('Profile'))
