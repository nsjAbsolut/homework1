import socket,sys,json,msgpack,cbor2
from data import PROFILE
from helpers import protobuf_profile
HOST,PORT='127.0.0.1',9999
FMT=sys.argv[1] if len(sys.argv)>1 else 'json'
encoders={'json':lambda:json.dumps(PROFILE,ensure_ascii=False).encode(),'msgpack':lambda:msgpack.packb(PROFILE,use_bin_type=True),'cbor':lambda:cbor2.dumps(PROFILE),'protobuf':lambda:protobuf_profile().SerializeToString()}
if FMT not in encoders: raise ValueError('Формат должен быть json/msgpack/cbor/protobuf')
payload=encoders[FMT]()
with socket.create_connection((HOST,PORT),timeout=5) as client:
 client.sendall({'json':b'J','msgpack':b'M','cbor':b'C','protobuf':b'P'}[FMT]+len(payload).to_bytes(4,'big')+payload)
print(f'Отправлено: {FMT}, {len(payload)} байт')
