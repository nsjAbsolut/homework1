import json,yaml,msgpack,cbor2
import xml.etree.ElementTree as ET
from pathlib import Path
from data import PROFILE
from helpers import dict_to_xml,protobuf_profile
formats={'JSON':json.dumps(PROFILE,ensure_ascii=False).encode(),'XML':ET.tostring(dict_to_xml('profile',PROFILE),encoding='utf-8'),'YAML':yaml.dump(PROFILE,allow_unicode=True).encode(),'MessagePack':msgpack.packb(PROFILE,use_bin_type=True),'CBOR':cbor2.dumps(PROFILE),'Protobuf':protobuf_profile().SerializeToString()}
print(f"{'Формат':<14} {'Размер (байт)':>14} {'Читаем?':>10}")
for name,b in formats.items():print(f"{name:<14} {len(b):>14} {'да' if name in ('JSON','XML','YAML') else 'нет':>10}")
Path('received').mkdir(exist_ok=True)
Path('received/report.json').write_text(json.dumps([{'format':n,'wire_size_bytes':len(b)} for n,b in formats.items()],ensure_ascii=False,indent=2),encoding='utf-8')
