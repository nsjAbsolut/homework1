import json
from data import PROFILE
s=json.dumps(PROFILE,ensure_ascii=False,indent=2)
print('=== JSON ===\n'+s+'\nРазмер:',len(s.encode()),'байт')
assert json.loads(s)==PROFILE
print('Десериализация успешна:',PROFILE['name'])
